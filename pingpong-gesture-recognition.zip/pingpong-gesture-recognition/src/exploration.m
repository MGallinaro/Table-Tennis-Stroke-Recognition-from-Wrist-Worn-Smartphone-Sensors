%% ==========================================================================================
%  ============================  EXPLORATION  ===============================================
%  ==========================================================================================
%  Archive of the tests that led to the choices of the pipeline (preprocessing_pipeline.m).
%  Each part is self-contained.
%
%  PART A (sections 1-6): early tests on the raw file, at 400 rows per second.
%      They were run BEFORE discovering that every sensor value is repeated 8 times
%      (see PART B), so fs = 400 here and the numbers in the comments refer to that setup.
%  PART B (sections 7-8): check of the true sensor sampling rate (50 Hz).
%  PART C (sections 9-12): analyses on the pipeline results; they load preprocessing.mat
%      (run preprocessing_pipeline.m first).

%% ==========================================================================================
%  ============================  A1 - LOAD AND FILTER (400 rows/s)  =========================
%  ==========================================================================================

clear all
[nomeFile, cartella] = uigetfile('*.mat', 'Select dataset_anon.mat');
if isequal(nomeFile, 0)
    error('No file selected.');
end
dati = load(fullfile(cartella, nomeFile));
dataset = dati.dataset;

fs = 400;
inizio = 5*fs + 1;                  % first sample after 5 s
moltiplicatore_soglia = 2.0;
distanzaMin = 400;                  % samples (1 s at 400 rows/s)

[b, a] = butter(2, 0.5/(fs/2), 'high');
activities = {'S', 'TPD', 'TPR'};

filt_matrix = struct();
for j = 1:numel(activities)
    activityName = activities{j};
    Acquisition_names = fieldnames(dataset.(activityName));
    for i = 1:numel(Acquisition_names)
        nome = Acquisition_names{i};
        filt_matrix.(activityName).(nome).Acc  = filter(b, a, dataset.(activityName).(nome).Acc);
        filt_matrix.(activityName).(nome).Gyro = filter(b, a, dataset.(activityName).(nome).Gyro);
    end
end

filt_matrix.TPD = rmfield(filt_matrix.TPD, 'P01_File5');
filt_matrix.TPR = rmfield(filt_matrix.TPR, 'P01_File5');
filt_matrix.TPR = rmfield(filt_matrix.TPR, 'P01_File1');
filt_matrix.TPR = rmfield(filt_matrix.TPR, 'P01_File2');

timeVector = (0:size(filt_matrix.S.P04_File1.Acc, 1)-1) / fs;

%% ==========================================================================================
%  ============================  A2 - CONTROL PLOT (one subject, 3 activities)  =============
%  ==========================================================================================

figure
for j = 1:numel(activities)
    activityName = activities{j};
    segnale = filt_matrix.(activityName).P04_File1;

    subplot(numel(activities), 2, 2*j-1)
    plot(timeVector, segnale.Acc)
    title([activityName ' - Acc'])
    xlabel('Time (s)'), ylabel('Acceleration')
    legend('x', 'y', 'z'), grid on

    subplot(numel(activities), 2, 2*j)
    plot(timeVector, segnale.Gyro)
    title([activityName ' - Gyro'])
    xlabel('Time (s)'), ylabel('Angular velocity')
    legend('x', 'y', 'z'), grid on
end

%% ==========================================================================================
%  ============================  A3 - AMPLITUDE: STD OF THE MAGNITUDE (serve)  ==============
%  ==========================================================================================
% Result: std from 1.8 to 9.7; the same person varies as much as different people.

Aquisition_S = fieldnames(filt_matrix.S);
stdAccModulo = zeros(1, numel(Aquisition_S));

for i = 1:numel(Aquisition_S)
    nome = Aquisition_S{i};
    accModulo = sqrt(sum(filt_matrix.S.(nome).Acc.^2, 2));
    stdAccModulo(i) = std(accModulo(inizio:end));
end

[~, iMin] = min(stdAccModulo);
[~, iMax] = max(stdAccModulo);
nomeMin = Aquisition_S{iMin}        % P03_File1
nomeMax = Aquisition_S{iMax}        % P09_File2

%% ==========================================================================================
%  ============================  A4 - FIXED THRESHOLD ON THE TWO EXTREME RECORDINGS  ========
%  ==========================================================================================
% Result: with a threshold of 10 no peak is found in P03_File1 -> a fixed threshold does not work.

ModuloData_std_min = sqrt(sum(filt_matrix.S.(nomeMin).Acc.^2, 2));
ModuloData_std_max = sqrt(sum(filt_matrix.S.(nomeMax).Acc.^2, 2));

[moduloPeaksMin, moduloLocMin] = findpeaks(ModuloData_std_min, 'MinPeakHeight', 10, 'MinPeakDistance', distanzaMin);
[moduloPeaksMax, moduloLocMax] = findpeaks(ModuloData_std_max, 'MinPeakHeight', 10, 'MinPeakDistance', distanzaMin);

figure
subplot(1, 2, 1)
plot(timeVector, ModuloData_std_min, 'DisplayName', 'Magnitude')
hold on
plot(timeVector(moduloLocMin), moduloPeaksMin, 'o', 'DisplayName', 'Peaks found')
title([nomeMin ' (minimum std) - fixed threshold 10'], 'Interpreter', 'none')
xlabel('Time (s)'), ylabel('Acceleration magnitude'), legend, grid on

subplot(1, 2, 2)
plot(timeVector, ModuloData_std_max, 'DisplayName', 'Magnitude')
hold on
plot(timeVector(moduloLocMax), moduloPeaksMax, 'o', 'DisplayName', 'Peaks found')
title([nomeMax ' (maximum std) - fixed threshold 10'], 'Interpreter', 'none')
xlabel('Time (s)'), ylabel('Acceleration magnitude'), legend, grid on

%% ==========================================================================================
%  ============================  A5 - CANDIDATE STATISTICS FOR THE THRESHOLD  ===============
%  ==========================================================================================
% Only with the median is the ratio (right threshold / statistic) similar in the three recordings.
% P01_File1 | std 3.52 | median 4.06 | 90th perc.  9.24 | 95th perc. 12.20
% P03_File1 | std 1.78 | median 2.22 | 90th perc.  5.40 | 95th perc.  6.07
% P09_File2 | std 9.67 | median 6.08 | 90th perc. 24.46 | 95th perc. 29.93

nomiRiferimento = {'P03_File1', 'P01_File1', 'P09_File2'};

for k = 1:numel(nomiRiferimento)
    m = sqrt(sum(filt_matrix.S.(nomiRiferimento{k}).Acc.^2, 2));
    m = m(inizio:end);
    fprintf('%-10s | std %5.2f | median %5.2f | 90th perc. %5.2f | 95th perc. %5.2f\n', ...
        nomiRiferimento{k}, std(m), median(m), prctile(m, 90), prctile(m, 95));
end

%% ==========================================================================================
%  ============================  A6 - ADAPTIVE THRESHOLD ON THE TWO EXTREME RECORDINGS  =====
%  ==========================================================================================
% Result with multiplier 2.0: all strokes found in both.

tratti  = {ModuloData_std_min(inizio:end), ModuloData_std_max(inizio:end)};
nomiEst = {nomeMin, nomeMax};
timeCut = ((inizio:numel(ModuloData_std_min)) - 1) / fs;

figure
for k = 1:2
    soglia = moltiplicatore_soglia * median(tratti{k});
    [pk, lc] = findpeaks(tratti{k}, 'MinPeakHeight', soglia, 'MinPeakDistance', distanzaMin);

    subplot(1, 2, k)
    plot(timeCut, tratti{k}, 'DisplayName', 'Magnitude')
    hold on
    plot(timeCut(lc), pk, 'ro', 'DisplayName', 'Peaks found')
    yline(soglia, '--', 'DisplayName', 'Threshold')
    title(sprintf('%s | threshold %.1f | %d peaks', nomiEst{k}, soglia, numel(lc)), 'Interpreter', 'none')
    xlabel('Time (s)'), ylabel('Acceleration magnitude'), legend, grid on
end

%% ==========================================================================================
%  ============================  B7 - TRUE SAMPLING RATE OF THE SENSORS  ====================
%  ==========================================================================================
% The signals look like "staircases": every value is held for several rows.
% Checks on the RAW dataset (requires `dataset` from section A1).

attivita = {'S', 'TPD', 'TPR'};
sensori  = {'Acc', 'Gyro'};
tutteLunghezze = [];            % length of every step, whole dataset
fraz8          = [];            % per recording: fraction of steps exactly 8 rows long
residui        = [];            % position of the changes, modulo 8
assiInsieme    = [];            % per recording: do the 3 axes change on the same rows?
ripetutiDopo   = [];            % per recording: repeated values after decimation 1:8:end

for k = 1:numel(attivita)
    nomi = fieldnames(dataset.(attivita{k}));
    for i = 1:numel(nomi)
        for s = 1:numel(sensori)
            M = dataset.(attivita{k}).(nomi{i}).(sensori{s});        % 24001 x 3, raw

            % 1-2) length of the steps (x axis)
            cambi = find(diff(M(:,1)) ~= 0);
            lung  = diff(cambi);
            tutteLunghezze = [tutteLunghezze; lung]; %#ok<AGROW>
            fraz8(end+1) = mean(lung == 8); %#ok<SAGROW>

            % 3) alignment to a fixed grid: remainder of the division by 8
            residui = [residui; mod(cambi, 8)]; %#ok<AGROW>

            % 4) do the three axes change together? (a row "changes" if at least one axis changes)
            cambiaX   = diff(M(:,1)) ~= 0;
            cambiaAny = any(diff(M) ~= 0, 2);
            assiInsieme(end+1) = mean(cambiaAny == cambiaX); %#ok<SAGROW>

            % 5) repeated values after decimation
            R = M(1:8:end, 1);
            ripetutiDopo(end+1) = mean(diff(R) == 0); %#ok<SAGROW>
        end
    end
end

fprintf('\n1) Step lengths over the whole dataset:\n');
tabulate(tutteLunghezze)
fprintf('2) Recording-sensor pairs with ALL steps 8 rows long: %d of %d\n', sum(fraz8 == 1), numel(fraz8));
fprintf('   Minimum fraction of 8-row steps in a recording: %.3f\n', min(fraz8));
fprintf('3) Remainders of the changes modulo 8 (a single value = fixed grid):\n');
tabulate(residui)
fprintf('4) Agreement between changes of x and of x/y/z: minimum %.3f (expected 1)\n', min(assiInsieme));
fprintf('5) Repeated values after 1:8:end: maximum %.4f (expected about 0)\n', max(ripetutiDopo));

%% ==========================================================================================
%  ============================  B8 - UPDATES PER SECOND, EVERY RECORDING  ==================
%  ==========================================================================================

durata = 60;                                         % seconds per recording
tab = table();
for k = 1:numel(attivita)
    nomi = fieldnames(dataset.(attivita{k}));
    for i = 1:numel(nomi)
        x = dataset.(attivita{k}).(nomi{i}).Acc(:,1);
        nCambi = sum(diff(x) ~= 0);
        tab = [tab; table(string(attivita{k}), string(nomi{i}), nCambi/durata, ...
            median(diff(find(diff(x) ~= 0))), ...
            'VariableNames', {'Activity', 'Name', 'UpdatesPerSecond', 'MedianStep'})]; %#ok<AGROW>
    end
end
tab = sortrows(tab, 'UpdatesPerSecond');
disp(tab(1:10, :))        % the 10 slowest
disp(tab(end-9:end, :))   % the 10 fastest
figure
histogram(tab.UpdatesPerSecond, 30), xlabel('Updates per second'), ylabel('Recordings')

%% ==========================================================================================
%  ============================  C9 - QUALITY CHECK RANKINGS (all activities)  ==============
%  ==========================================================================================

clear all
load('preprocessing.mat', 'peaksStruct', 'filt_matrix', 'fs', 'inizio')   % fs = 50 Hz
activities = {'S', 'TPD', 'TPR'};

for k = 1:numel(activities)
    activityName = activities{k};
    nomi = fieldnames(filt_matrix.(activityName));

    T_max = table(nomi, peaksStruct.(activityName).rapportoMaxMediano', ...
        'VariableNames', {'Name', 'MaxRatio'});
    T_max = sortrows(T_max, 'MaxRatio', 'descend');

    T_min = table(nomi, peaksStruct.(activityName).rapportoMinMediano', ...
        'VariableNames', {'Name', 'MinRatio'});
    T_min = sortrows(T_min, 'MinRatio', 'ascend');

    fprintf('\n=== %s - missed strokes (max/median) ===\n', activityName);
    disp(T_max(1:min(10, height(T_max)), :))
    fprintf('\n=== %s - false peaks (min/median) ===\n', activityName);
    disp(T_min(1:min(10, height(T_min)), :))
end

%% ==========================================================================================
%  ============================  C10 - INSPECTION OF ONE RECORDING  =========================
%  ==========================================================================================
% Reads ONLY from peaksStruct (no recomputation). Bands: green = interval too long
% (look for a missed stroke), magenta = interval too short (one of the two peaks is false).

attivitaIspezione = 'TPD';
nomeIspezione     = 'P03_File5';

R = peaksStruct.(attivitaIspezione).(nomeIspezione);
t = (0:numel(R.modulo)-1) / fs;
intMed = median(R.intervalli);
jLunghi = find(R.intervalli > 1.6 * intMed)';   % transposed to a row: "for" iterates over columns
jCorti  = find(R.intervalli < 0.6 * intMed)';

figure
plot(t(inizio:end), R.modulo(inizio:end), 'DisplayName', 'Magnitude')
hold on
plot(R.tempo, R.picchi, 'ro', 'DisplayName', 'Peaks found')
yline(R.soglia, '--', 'DisplayName', 'Threshold')
for j = jLunghi
    xline(R.tempo(j),   'g', 'HandleVisibility', 'off')
    xline(R.tempo(j+1), 'g', 'HandleVisibility', 'off')
end
for j = jCorti
    xline(R.tempo(j),   'm', 'HandleVisibility', 'off')
    xline(R.tempo(j+1), 'm', 'HandleVisibility', 'off')
end
title(sprintf('%s - %s | threshold %.1f | %d peaks | long %d, short %d', attivitaIspezione, ...
    nomeIspezione, R.soglia, R.numPicchi, numel(jLunghi), numel(jCorti)), 'Interpreter', 'none')
xlabel('Time (s)'), ylabel('Acceleration magnitude'), legend, grid on

%% ==========================================================================================
%  ============================  C11 - FALSE PEAK REMOVAL ON ONE RECORDING  =================
%  ==========================================================================================
% Prototype of section 6 of preprocessing_pipeline.m.

loc = peaksStruct.TPD.P03_File5.loc;
pk  = peaksStruct.TPD.P03_File5.picchi;
intMedCampioni = median(diff(loc));         % computed ONCE, before removing anything
nPrima = numel(loc);

while true
    intervalli = diff(loc);                                % recomputed at every iteration
    j = find(intervalli < 0.6*intMedCampioni, 1);          % only the FIRST short interval
    if isempty(j)                                          % none left -> done
        break
    end
    if pk(j) < pk(j+1)
        togli = j;
    else
        togli = j + 1;
    end
    loc(togli) = [];
    pk(togli)  = [];
end

fprintf('Peaks: %d before, %d after (%d removed)\n', nPrima, numel(loc), nPrima - numel(loc));

% check: no interval must remain below the red line
figure
plot(diff(loc), 'o-', 'DisplayName', 'Intervals after cleaning')
hold on
yline(intMedCampioni, 'y', 'DisplayName', 'Median')
yline(0.6*intMedCampioni, '--r', 'DisplayName', 'False peak limit')
grid on, legend
title('TPD - P03\_File5 after false peak removal')

%% ==========================================================================================
%  ============================  C12 - FIRST 10 s OF THREE RECORDINGS  =====================
%  ==========================================================================================
% Is the 3-4 s segment a controlled rest? Not always: in many recordings the subject
% is already moving. Used to judge the "rest" statistics of section 9 of the pipeline.

figure
esempi = {'S', 'P03_File1'; 'TPD', 'P05_File2'; 'TPR', 'P11_File3'};
t = (0:10*fs-1) / fs;
for e = 1:size(esempi, 1)
    m = peaksStruct.(esempi{e,1}).(esempi{e,2}).modulo;
    subplot(3, 1, e)
    plot(t, m(1:10*fs)), hold on
    xline([3 4 5], '--r')
    title([esempi{e,1} ' - ' esempi{e,2}], 'Interpreter', 'none'), grid on
end
xlabel('Time (s)')
