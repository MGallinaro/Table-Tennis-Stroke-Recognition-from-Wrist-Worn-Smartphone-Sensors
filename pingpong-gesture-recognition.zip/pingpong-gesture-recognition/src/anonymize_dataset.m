%% ==========================================================================================
%  ============================  ANONYMIZE DATASET  =========================================
%  ==========================================================================================
%  Run ONCE, before everything else.
%  The original dataset names each recording <Surname>_File<N>. This script replaces every
%  surname with a code (P01, P02, ...) and saves the result as dataset_anon.mat.
%  Codes are assigned in alphabetical order of the surnames, so the mapping is always the same.
%
%  The key (code -> surname) is saved in subject_key_PRIVATE.mat, which must NEVER be
%  published (it is excluded by .gitignore). Only the anonymized dataset is shared, in data/.
%  This script cannot be run from the repository: it needs the original (non-anonymized) file.

clear all
clc

%% Load the original dataset
[fileName, folder] = uigetfile('*.mat', 'Select the ORIGINAL dataset');
if isequal(fileName, 0)
    error('No file selected.');
end
raw = load(fullfile(folder, fileName));
dataset = raw.dataset;

%% Collect the subjects (first part of every recording name)
activities = fieldnames(dataset);
allSubjects = {};
for k = 1:numel(activities)
    recNames = fieldnames(dataset.(activities{k}));
    for i = 1:numel(recNames)
        parts = strsplit(recNames{i}, '_');
        allSubjects{end+1} = parts{1}; %#ok<SAGROW>
    end
end
subjects = unique(allSubjects);                     % sorted alphabetically
codes    = compose('P%02d', 1:numel(subjects));     % P01, P02, ...
assert(numel(subjects) == 11, 'Expected 11 subjects, found %d', numel(subjects));

%% Rebuild the struct with the new names (same order as the original)
datasetAnon = struct();
for k = 1:numel(activities)
    act = activities{k};
    recNames = fieldnames(dataset.(act));
    for i = 1:numel(recNames)
        parts   = strsplit(recNames{i}, '_');
        code    = codes{strcmp(subjects, parts{1})};
        newName = [code, recNames{i}(numel(parts{1}) + 1:end)];   % P01_File1
        datasetAnon.(act).(newName) = dataset.(act).(recNames{i});
    end
end

%% Check: same number of recordings, same data
for k = 1:numel(activities)
    act = activities{k};
    oldNames = fieldnames(dataset.(act));
    newNames = fieldnames(datasetAnon.(act));
    assert(numel(oldNames) == numel(newNames));
    for i = 1:numel(oldNames)
        assert(isequal(dataset.(act).(oldNames{i}), datasetAnon.(act).(newNames{i})));
    end
end
disp('Anonymization check passed.')

%% Save
dataset = datasetAnon;                              % same variable name used by the other scripts
save('dataset_anon.mat', 'dataset');

subjectKey = table(codes', subjects', 'VariableNames', {'Code', 'Subject'});
save('subject_key_PRIVATE.mat', 'subjectKey');      % DO NOT PUBLISH
disp(subjectKey)
