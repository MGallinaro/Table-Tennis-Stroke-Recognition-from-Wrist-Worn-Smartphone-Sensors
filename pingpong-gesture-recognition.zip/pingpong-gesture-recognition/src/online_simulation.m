%% ==========================================================================================
%  ============================  ONLINE SIMULATION  =========================================
%  ==========================================================================================
%  A recording is read one sample at a time, as if it were arriving from the phone.
%  At every sample: filter -> magnitude queue -> buffer -> threshold -> peak? -> network.
%
%  Sections 1-5: reference implementation written as a plain loop, with its checks.
%  Section 6   : verification of passoOnline_debug.m against the reference loop.
%  Section 7   : final function passoOnline.m, used as it will be in Simulink.
%
%  Requires: dataset_anon.mat, cnn_model.mat, passoOnline.m, passoOnline_debug.m

close all
clear all
clc

%% ==========================================================================================
%  ============================  1 - LOAD DATA AND MODEL  ===================================
%  ==========================================================================================

[nomeFile, cartella] = uigetfile('*.mat', 'Select dataset_anon.mat');
if isequal(nomeFile, 0)
    error('No file selected.');
end
dati = load(fullfile(cartella, nomeFile));
dataset = dati.dataset;

modello = load('cnn_model.mat');   % net, XMedia, Xstd, classi
net    = modello.net;
XMedia = modello.XMedia;
Xstd   = modello.Xstd;
classi = modello.classi;

%% ==========================================================================================
%  ============================  2 - PARAMETERS AND RECORDING  ==============================
%  ==========================================================================================

fattore = 8;
fs = 400 / fattore;                 % 50 Hz
nFinestra = 50;
centro = 26;                        % row of the peak in the window (25 before, 24 after)
moltiplicatore_soglia = 2;
soglia_minima = 2;
nAvvio = 3 * fs;                    % first 3 s = 150 samples (filter transient)

% recording to simulate (P04 and P07 are the test subjects)
attivita = 'TPD';
nomeRec  = 'P04_File1';

rec = dataset.(attivita).(nomeRec);
segnale = [rec.Acc(1:fattore:end, :), rec.Gyro(1:fattore:end, :)];   % decimated, NOT filtered
N = size(segnale, 1);

[b, a] = butter(2, 0.5/(fs/2), 'high');

%% ==========================================================================================
%  ============================  3 - REFERENCE LOOP  ========================================
%  ==========================================================================================

Buffer         = zeros(nFinestra, 6);
stato          = zeros(max(numel(a), numel(b)) - 1, 6);   % filter state: 2 rows x 6 channels
storiaModulo   = zeros(10*fs, 1);
ultimoPicco    = -inf;

filtratoOnline = zeros(size(segnale));   % only for the checks
soglia         = NaN(N, 1);              % only for the checks and the plot
nDopoAvvio     = 0;                      % only for the checks
tPicchi        = [];
classiOnline   = strings(0, 1);

for t = 1:N
    campione = segnale(t, :);

    % causal filter, continuing from the previous state
    [campione_filt, stato] = filter(b, a, campione, stato, 1);
    filtratoOnline(t, :) = campione_filt;

    % magnitude queue (last 10 s) and window buffer (last 50 samples)
    modulo = sqrt(sum(campione_filt(1:3).^2, 2));
    storiaModulo = [storiaModulo(2:end); modulo];
    Buffer = [Buffer(2:end, :); campione_filt];

    % --- start-up: nothing is decided during the first 3 s ---
    if t <= nAvvio
        continue
    end
    nDopoAvvio = nDopoAvvio + 1;

    % --- THRESHOLD ---------------------------------------------------------------
    % The queue starts with 500 zeros: at every sample an old value leaves and a real
    % magnitude enters. nValidi = how many magnitudes arrived AFTER the start-up:
    % it starts at 1 (t = 151), grows by 1 per sample and stops at 500 (t = 650).
    % The median is computed only over those values, so the initial zeros do not pull
    % it down. The window first grows, then slides (always the last 10 s).
    % Threshold = 2 x median, as offline, but never below 2 (phone at rest, long pauses).
    nValidi = min(t - nAvvio, 10*fs);
    sogliaModulo_Median = median(storiaModulo(end-nValidi+1 : end));
    soglia(t) = max(sogliaModulo_Median * moltiplicatore_soglia, soglia_minima);

    % --- PEAK --------------------------------------------------------------------
    % The central sample of the buffer (row 26) is a stroke if:
    %   1) it is the highest of the 50 samples in the buffer (25 before, 24 after)
    %   2) it is above the threshold
    %   3) at least 1 s (fs samples) has passed since the last stroke
    % Row 26 and not row 50: a peak can be recognized only once the samples after it
    % have arrived. Delay: 24 samples (about 0.5 s).
    if t < nAvvio + nFinestra          % the buffer still contains start-up samples
        continue
    end
    moduloBuffer = sqrt(sum(Buffer(:, 1:3).^2, 2));
    [~, iMax] = max(moduloBuffer);
    tCentro = t - (nFinestra - centro);               % sample index of row 26

    if iMax == centro && moduloBuffer(centro) >= soglia(t) && tCentro - ultimoPicco >= fs
        ultimoPicco = tCentro;
        tPicchi(end+1, 1) = tCentro;
        % --- NETWORK: the buffer is already the window ---
        finestra = single((Buffer - XMedia) ./ Xstd);                       % same normalization as training
        scores   = minibatchpredict(net, finestra, InputDataFormats="TCB"); % 3 probabilities
        classiOnline(end+1, 1) = string(scores2label(scores, classi));      % most likely class
    end
end

%% ==========================================================================================
%  ============================  4 - CHECKS OF THE REFERENCE LOOP  ==========================
%  ==========================================================================================

filtratoOffline = filter(b, a, segnale);
moduloOffline   = sqrt(sum(filtratoOffline(:, 1:3).^2, 2));

fprintf('Filter, online vs offline (expected 0): %g\n', max(abs(filtratoOnline - filtratoOffline), [], 'all'));
fprintf('Magnitude queue vs offline (expected 0): %g\n', max(abs(storiaModulo - moduloOffline(end-10*fs+1:end))));
fprintf('Samples after start-up (expected %d): %d\n', N - nAvvio, nDopoAvvio);
fprintf('Strokes found online: %d\n', numel(tPicchi));
fprintf('Classified as %s: %d of %d\n', attivita, sum(classiOnline == attivita), numel(classiOnline));

%% ==========================================================================================
%  ============================  5 - PLOT  ==================================================
%  ==========================================================================================

tempo  = (0:N-1) / fs;
giusti = classiOnline == attivita;

figure
plot(tempo, moduloOffline, 'DisplayName', 'Acceleration magnitude'), hold on
plot(tempo, soglia, '--', 'LineWidth', 1.5, 'DisplayName', 'Online threshold')
plot((tPicchi(giusti) - 1)/fs, moduloOffline(tPicchi(giusti)), 'x', 'MarkerSize', 10, ...
    'LineWidth', 2, 'DisplayName', 'Stroke, correct class')
plot((tPicchi(~giusti) - 1)/fs, moduloOffline(tPicchi(~giusti)), 'x', 'MarkerSize', 10, ...
    'LineWidth', 2, 'DisplayName', 'Stroke, wrong class')
xline(nAvvio/fs, ':', 'End of start-up', 'HandleVisibility', 'off')
xlabel('Time (s)'), ylabel('Acceleration magnitude'), legend, grid on
title(sprintf('%s - %s: online simulation', attivita, nomeRec), 'Interpreter', 'none')

%% ==========================================================================================
%  ============================  6 - VERIFICATION OF passoOnline_debug  =====================
%  ==========================================================================================
% The function is called one sample at a time and must give EXACTLY the same result
% as the reference loop: filter, buffer, threshold, stroke times and classes.

clear passoOnline_debug                         % reset the function memory
filtratoFunzione    = zeros(size(segnale));
Confronto_buffVsOff = zeros(N, 1);
SogliaIn            = zeros(N, 1);
tPicchiFun          = [];
classiFun           = strings(0, 1);

for k = 1:N
    [colpo, finestra, campione_filt, BufferOut, SogliaOut, tCentro] = ...
        passoOnline_debug(segnale(k, :), b, a, XMedia, Xstd);

    filtratoFunzione(k, :) = campione_filt;
    SogliaIn(k) = SogliaOut;
    if k > 49
        Confronto_buffVsOff(k) = max(abs(BufferOut - filtratoOffline(k-49:k, :)), [], 'all');
    end
    if colpo                                    % the network and the lists stay OUTSIDE the function
        tPicchiFun(end+1, 1) = tCentro;
        classiFun(end+1, 1)  = string(scores2label( ...
            minibatchpredict(net, finestra, InputDataFormats="TCB"), classi));
    end
end

fprintf('\n--- passoOnline_debug vs reference loop ---\n');
fprintf('Filter     (expected 0): %g\n', max(abs(filtratoFunzione - filtratoOffline), [], 'all'));
fprintf('Buffer     (expected 0): %g\n', max(Confronto_buffVsOff));
fprintf('Threshold  (expected 0): %g\n', max(abs(soglia - SogliaIn), [], 'all'));
fprintf('NaN match  (expected 1): %d\n', isequal(isnan(soglia), isnan(SogliaIn)));
fprintf('Peak times (expected 1): %d\n', isequal(tPicchi, tPicchiFun));
fprintf('Classes    (expected 1): %d\n', isequal(classiOnline, classiFun));

%% ==========================================================================================
%  ============================  7 - FINAL FUNCTION (as in Simulink)  =======================
%  ==========================================================================================
% Only two outputs: colpo and finestra. The network runs only when colpo = true.

clear passoOnline
classiFinali = strings(0, 1);
for k = 1:N
    [colpo, finestra] = passoOnline(segnale(k, :), b, a, XMedia, Xstd);
    if colpo
        scores = minibatchpredict(net, finestra, InputDataFormats="TCB");
        classiFinali(end+1, 1) = string(scores2label(scores, classi));
    end
end
fprintf('\npassoOnline: %d strokes, same classes as the reference loop: %d\n', ...
    numel(classiFinali), isequal(classiFinali, classiOnline));
