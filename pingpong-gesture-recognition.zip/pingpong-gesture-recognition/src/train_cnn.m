%% ==========================================================================================
%  ============================  TRAIN THE 1D CNN  ==========================================
%  ==========================================================================================
%  Input : windows.mat   (from preprocessing_pipeline.m)
%  Output: cnn_model.mat (net, XMedia, Xstd, classi)
%
%  Subject-wise split, to avoid data leakage: windows of the same person never end up
%  in two different sets.

clear all
rng(0)

%% ==========================================================================================
%  ============================  1 - LOAD WINDOWS  ==========================================
%  ==========================================================================================

load('windows.mat')

%% ==========================================================================================
%  ============================  2 - SPLIT AND NORMALIZATION  ===============================
%  ==========================================================================================

soggetti_Test = {'P04', 'P07'};
soggetti_Val  = {'P02', 'P10'};
soggetti_Tra  = {'P01', 'P03', 'P05', 'P06', 'P08', 'P09', 'P11'};

isTest = ismember(soggetto, soggetti_Test);
isVal  = ismember(soggetto, soggetti_Val);
isTra  = ismember(soggetto, soggetti_Tra);

nInsiemi = isTra + isVal + isTest;
assert(all(nInsiemi == 1), 'Split error: windows in 0 or 2 sets');

fprintf('Windows: train %d | validation %d | test %d\n', sum(isTra), sum(isVal), sum(isTest));

XTrain = X(:, :, isTra);
XVal   = X(:, :, isVal);
XTest  = X(:, :, isTest);

YTrain = Y(isTra);
YVal   = Y(isVal);
YTest  = Y(isTest);

% z-score per channel, statistics computed on the TRAIN set only
XMedia = mean(XTrain, [1 3]);
Xstd   = std(XTrain, 0, [1 3]);

XTrainNorm = (XTrain - XMedia) ./ max(Xstd, eps);
XValNorm   = (XVal   - XMedia) ./ max(Xstd, eps);
XTestNorm  = (XTest  - XMedia) ./ max(Xstd, eps);

% Check: train must be exactly mean 0 / std 1; test only approximately
squeeze(mean(XTrainNorm, [1 3]))'
squeeze(std(XTrainNorm, 0, [1 3]))'
squeeze(mean(XTestNorm, [1 3]))'
squeeze(std(XTestNorm, 0, [1 3]))'

%% ==========================================================================================
%  ============================  3 - NETWORK  ===============================================
%  ==========================================================================================

layers = [
    sequenceInputLayer(6, MinLength=50)
    convolution1dLayer(5, 32, Padding="same")
    batchNormalizationLayer
    reluLayer
    maxPooling1dLayer(2, Stride=2)
    convolution1dLayer(5, 64, Padding="same")
    batchNormalizationLayer
    reluLayer
    globalAveragePooling1dLayer
    dropoutLayer(0.3)
    fullyConnectedLayer(3)
    softmaxLayer
];

options = trainingOptions("adam", ...
    MaxEpochs=50, ...
    MiniBatchSize=64, ...
    Verbose=true, ...
    Plots="training-progress", ...
    Metrics="accuracy", ...
    ExecutionEnvironment="gpu", ...
    InputDataFormats="TCB", ...
    Shuffle="every-epoch", ...
    ValidationData={XValNorm, YVal}, ...
    ValidationFrequency=44, ...
    ValidationPatience=5, ...
    OutputNetwork="best-validation");

analyzeNetwork(layers)

%% ==========================================================================================
%  ============================  4 - TRAINING  ==============================================
%  ==========================================================================================

net = trainnet(XTrainNorm, YTrain, layers, "crossentropy", options);

%% ==========================================================================================
%  ============================  5 - TEST SET EVALUATION  ===================================
%  ==========================================================================================

classi = categories(YTrain);
scores = minibatchpredict(net, XTestNorm, InputDataFormats="TCB");
YPred  = scores2label(scores, classi);

accuracy = mean(YPred == YTest);
fprintf('Test set accuracy: %.2f%%\n', 100 * accuracy);

figure
confusionchart(YTest, YPred, ...
    'Title', 'Confusion matrix - Test set', ...
    'RowSummary', 'row-normalized', ...
    'ColumnSummary', 'column-normalized');

% one confusion matrix per test subject
soggTest = soggetto(isTest);
for s = 1:numel(soggetti_Test)
    isS = soggTest == soggetti_Test{s};
    figure
    confusionchart(YTest(isS), YPred(isS));
    title(sprintf('%s - accuracy %.1f%%', soggetti_Test{s}, 100 * mean(YPred(isS) == YTest(isS))))
end

%% ==========================================================================================
%  ============================  6 - SAVE  ==================================================
%  ==========================================================================================

save('cnn_model.mat', 'net', 'XMedia', 'Xstd', 'classi');
