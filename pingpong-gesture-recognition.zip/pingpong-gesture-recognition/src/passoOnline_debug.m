function [colpo, finestra, campione_filt, BufferOut, SogliaOut, tCentro] = passoOnline_debug(campione, b, a, XMedia, Xstd)
%PASSOONLINE_DEBUG  Same algorithm as passoOnline, with the internal signals as extra outputs.
%   Used only by online_simulation.m to verify the function step by step.
%
%   Extra outputs:
%   campione_filt : filtered sample (1x6)
%   BufferOut     : copy of the 50x6 buffer of filtered samples
%   SogliaOut     : current threshold (NaN during the start-up)
%   tCentro       : sample index of the peak (NaN before the buffer is ready;
%                   read it only when colpo = true)
%
%   Before processing a new recording: clear passoOnline_debug

% ---------------- parameters ----------------
fs = 50;
nFinestre = 50;
nAvvio = 3 * fs;
moltiplicatore_soglia = 2;
soglia_minima = 2;
centro = 26;

% ---------------- default outputs (cover every return) ----------------
colpo = false;
finestra = zeros(nFinestre, 6, 'single');
SogliaOut = NaN;
tCentro = NaN;

% ---------------- memory between calls ----------------
% a persistent variable cannot also be an output: BufferOut is a copy of buffer
persistent t stato buffer storiaModulo ultimoPicco
if isempty(t)
    t = 0;
    stato = zeros(max(numel(a), numel(b)) - 1, 6);
    buffer = zeros(nFinestre, 6);
    storiaModulo = zeros(10*fs, 1);
    ultimoPicco = -inf;
end
t = t + 1;

[campione_filt, stato] = filter(b, a, campione, stato, 1);

modulo = sqrt(sum(campione_filt(1:3).^2, 2));
storiaModulo = [storiaModulo(2:end); modulo];

buffer = [buffer(2:end, :); campione_filt];
BufferOut = buffer;

if t <= nAvvio
    return
end

nValidi = min(t - nAvvio, 10*fs);
sogliaModulo_Median = median(storiaModulo(end-nValidi+1 : end));
soglia = max(sogliaModulo_Median * moltiplicatore_soglia, soglia_minima);
SogliaOut = soglia;

if t < nAvvio + nFinestre
    return
end

moduloBuffer = sqrt(sum(buffer(:, 1:3).^2, 2));
[~, iMax] = max(moduloBuffer);
tCentro = t - (nFinestre - centro);

if iMax == centro && moduloBuffer(centro) >= soglia && tCentro - ultimoPicco >= fs
    colpo = true;
    ultimoPicco = tCentro;
    finestra = single((buffer - XMedia) ./ Xstd);   % same normalization as training
end
end
