function [colpo, finestra] = passoOnline(campione, b, a, XMedia, Xstd)
%PASSOONLINE  Online stroke detector: processes ONE sample per call.
%
%   [colpo, finestra] = passoOnline(campione, b, a, XMedia, Xstd)
%
%   INPUTS
%   campione      : 1x6 RAW sample [accX accY accZ gyroX gyroY gyroZ] at 50 Hz
%   b, a          : high-pass filter coefficients, butter(2, 0.5/(fs/2), 'high')
%   XMedia, Xstd  : 1x6 normalization statistics of the training set
%
%   OUTPUTS
%   colpo         : true when a stroke has just been detected
%   finestra      : 50x6 normalized window, ready for the network (zeros if colpo = false)
%
%   The network is NOT called here: it runs outside, only when colpo = true
%   (minibatchpredict in MATLAB, the Predict block in Simulink).
%   The stroke is reported 24 samples (about 0.5 s) after its peak.
%   Before processing a new recording: clear passoOnline
%
%   Verified sample by sample against the reference loop in online_simulation.m
%   (see passoOnline_debug.m, which also returns the internal signals).

% ---------------- parameters ----------------
fs = 50;
nFinestre = 50;                 % window length (1 s)
nAvvio = 3 * fs;                % first 3 s: filter transient, no decision
moltiplicatore_soglia = 2;      % threshold = 2 x median of the last 10 s
soglia_minima = 2;              % threshold floor (long pauses, phone at rest)
centro = 26;                    % row of the peak in the window (25 before, 24 after)

% ---------------- default outputs (cover every return) ----------------
colpo = false;
finestra = zeros(nFinestre, 6, 'single');

% ---------------- memory between calls ----------------
persistent t stato buffer storiaModulo ultimoPicco
if isempty(t)                                       % first call only
    t = 0;
    stato = zeros(max(numel(a), numel(b)) - 1, 6);  % filter state: 2 x 6
    buffer = zeros(nFinestre, 6);                   % last 50 filtered samples
    storiaModulo = zeros(10*fs, 1);                 % acceleration magnitude, last 10 s
    ultimoPicco = -inf;                             % "no stroke so far"
end
t = t + 1;

% ---------------- causal filter, continuing from the previous state ----------------
[campione_filt, stato] = filter(b, a, campione, stato, 1);

% ---------------- magnitude queue and window buffer ----------------
modulo = sqrt(sum(campione_filt(1:3).^2, 2));
storiaModulo = [storiaModulo(2:end); modulo];
buffer = [buffer(2:end, :); campione_filt];

% ---------------- start-up: filter transient ----------------
if t <= nAvvio
    return
end

% ---------------- hybrid threshold ----------------
% median only over the values that arrived after the start-up (not the initial zeros):
% the window first grows, then slides over the last 10 s
nValidi = min(t - nAvvio, 10*fs);
sogliaModulo_Median = median(storiaModulo(end-nValidi+1 : end));
soglia = max(sogliaModulo_Median * moltiplicatore_soglia, soglia_minima);

% ---------------- buffer must contain only post-start-up samples ----------------
if t < nAvvio + nFinestre
    return
end

% ---------------- peak test on the central row ----------------
% A stroke is detected when the central sample (row 26) is:
%   1) the maximum of the buffer
%   2) above the threshold
%   3) at least 1 s after the previous stroke
moduloBuffer = sqrt(sum(buffer(:, 1:3).^2, 2));
[~, iMax] = max(moduloBuffer);
tCentro = t - (nFinestre - centro);                 % sample index of row 26

if iMax == centro && moduloBuffer(centro) >= soglia && tCentro - ultimoPicco >= fs
    colpo = true;
    ultimoPicco = tCentro;
    finestra = single((buffer - XMedia) ./ Xstd);   % same normalization as training
end
end
