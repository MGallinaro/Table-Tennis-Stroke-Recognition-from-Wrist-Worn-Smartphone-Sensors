%% ==========================================================================================
%  ============================  PREPROCESSING PIPELINE  ====================================
%  ==========================================================================================
%  From the raw recordings to the training windows.
%  Input : dataset_anon.mat   (from anonymize_dataset.m)
%  Output: windows.mat        (X, Y, soggetto, registrazione, posizione, fs, durataFinestra)
%          preprocessing.mat  (peaksStruct, filt_matrix, fs, inizio)
%          threshold_stats_train.mat (statistics used to design the online threshold)
%
%  Data split by subject (used here in section 9 and in train_cnn.m):
%    train      : P01 P03 P05 P06 P08 P09 P11
%    validation : P02 P10
%    test       : P04 P07

clear all
clc
close all

%% ==========================================================================================
%  ============================  1 - LOAD DATASET  ==========================================
%  ==========================================================================================

[nomeFile, cartella] = uigetfile('*.mat', 'Select dataset_anon.mat');
if isequal(nomeFile, 0)
    error('No file selected.');
end
dati = load(fullfile(cartella, nomeFile));
dataset = dati.dataset;

%% ==========================================================================================
%  ============================  2 - PARAMETERS  ============================================
%  ==========================================================================================

fsOriginale  = 400;                   % rows per second in the FILE
fattore      = 8;                     % every sensor value is repeated 8 times in the file
fs           = fsOriginale / fattore; % 50 Hz: the TRUE sensor sampling rate
fTaglio      = 0.5;                   % high-pass cut-off frequency (Hz)
ordineFiltro = 2;

activities = {'S', 'TPD', 'TPR'};     % class F excluded: it is an exact copy of TPR

inizio = 5*fs + 1;                    % first sample after the initial 5 s (rest + filter transient)
moltiplicatore_soglia = 2.0;          % threshold = multiplier x median of the magnitude
distanzaMin = 1 * fs;                 % minimum distance between two peaks: 1 s, in samples

%% ==========================================================================================
%  ============================  3 - DECIMATION, FILTERING, CLEANING  =======================
%  ==========================================================================================
% filter (causal), not filtfilt: it must be reproducible sample by sample in real time.

[b, a] = butter(ordineFiltro, fTaglio/(fs/2), 'high');

filt_matrix = struct();
for j = 1:numel(activities)
    activityName = activities{j};
    Acquisition_names = fieldnames(dataset.(activityName));
    for i = 1:numel(Acquisition_names)
        nome = Acquisition_names{i};
        % drop the copies: one row every 8 -> from 400 to 50 rows per second
        Acc  = dataset.(activityName).(nome).Acc(1:fattore:end, :);
        Gyro = dataset.(activityName).(nome).Gyro(1:fattore:end, :);

        filt_matrix.(activityName).(nome).Acc  = filter(b, a, Acc);
        filt_matrix.(activityName).(nome).Gyro = filter(b, a, Gyro);
    end
end

% P01_File5 is a copy of P01_File4 in TPD and TPR
filt_matrix.TPD = rmfield(filt_matrix.TPD, 'P01_File5');
filt_matrix.TPR = rmfield(filt_matrix.TPR, 'P01_File5');
% P01_File1 and P01_File2 (TPR only): continuous movement with no rest baseline,
% the 2 x median threshold is above almost every stroke (6 and 4 peaks found out of ~45)
filt_matrix.TPR = rmfield(filt_matrix.TPR, 'P01_File1');
filt_matrix.TPR = rmfield(filt_matrix.TPR, 'P01_File2');

for j = 1:numel(activities)
    fprintf('%-4s: %d recordings\n', activities{j}, numel(fieldnames(filt_matrix.(activities{j}))));
end
% Expected: S 55, TPD 54, TPR 52

%% ==========================================================================================
%  ============================  4 - STROKE DETECTION (S, TPD, TPR)  ========================
%  ==========================================================================================
% Acceleration magnitude + adaptive threshold (multiplier x median).
% loc refers to the FULL signal: it is used directly to cut the windows.

peaksStruct = struct();

for k = 1:numel(activities)
    activityName = activities{k};
    nomiAcquisizioni = fieldnames(filt_matrix.(activityName));
    nReg = numel(nomiAcquisizioni);

    % one value per recording, reset for every activity
    numPicchi  = zeros(1, nReg);
    intMediano = NaN(1, nReg);
    intMin     = NaN(1, nReg);
    intMax     = NaN(1, nReg);

    for i = 1:nReg
        nome_File = nomiAcquisizioni{i};

        % magnitude of the filtered acceleration, without the first 5 s
        A = filt_matrix.(activityName).(nome_File).Acc;
        modulo = sqrt(sum(A.^2, 2));
        tratto = modulo(inizio:end);

        % threshold from the median, then peak search
        soglia = moltiplicatore_soglia * median(tratto);
        [picchi, loc] = findpeaks(tratto, ...
            'MinPeakHeight', soglia, 'MinPeakDistance', distanzaMin);
        loc = loc + inizio - 1;                 % position in the full signal
        intervalli = diff(loc) / fs;            % seconds between consecutive strokes

        % recording metrics (at least 2 peaks are needed to have intervals)
        numPicchi(i) = numel(loc);
        if numel(intervalli) >= 1
            intMax(i)     = max(intervalli);
            intMin(i)     = min(intervalli);
            intMediano(i) = median(intervalli);
        end

        fprintf('%-4s %-10s | threshold %5.2f | peaks %2d | interval min %.2f  median %.2f  max %.2f s\n', ...
            activityName, nome_File, soglia, numPicchi(i), intMin(i), intMediano(i), intMax(i));

        % data of the single recording
        peaksStruct.(activityName).(nome_File).soglia     = soglia;
        peaksStruct.(activityName).(nome_File).modulo     = modulo;
        peaksStruct.(activityName).(nome_File).picchi     = picchi;
        peaksStruct.(activityName).(nome_File).numPicchi  = numPicchi(i);
        peaksStruct.(activityName).(nome_File).loc        = loc;
        peaksStruct.(activityName).(nome_File).intervalli = intervalli;
        peaksStruct.(activityName).(nome_File).tempo      = (loc - 1) / fs;
    end

    % activity vectors (one cell per recording)
    peaksStruct.(activityName).numPicchi  = numPicchi;
    peaksStruct.(activityName).intMax     = intMax;
    peaksStruct.(activityName).intMin     = intMin;
    peaksStruct.(activityName).intMediano = intMediano;
    peaksStruct.(activityName).rapportoMaxMediano = intMax ./ intMediano;
    peaksStruct.(activityName).rapportoMinMediano = intMin ./ intMediano;

    % quality check: recordings with an irregular rhythm
    peaksStruct.(activityName).sospettiMancati = nomiAcquisizioni(intMax > 1.6 * intMediano);
    peaksStruct.(activityName).sospettiFalsi   = nomiAcquisizioni(intMin < 0.6 * intMediano);

    fprintf('\n%s: %d recordings, %d with possible missed strokes, %d with possible false peaks\n\n', ...
        activityName, nReg, numel(peaksStruct.(activityName).sospettiMancati), ...
        numel(peaksStruct.(activityName).sospettiFalsi));
end

% Check
fprintf('Recordings in peaksStruct: S %d | TPD %d | TPR %d\n', ...
    numel(peaksStruct.S.numPicchi), numel(peaksStruct.TPD.numPicchi), numel(peaksStruct.TPR.numPicchi));
% Expected: S 55 | TPD 54 | TPR 52

%% ==========================================================================================
%  ============================  5 - QUALITY CHECK: WORST RECORDINGS  =======================
%  ==========================================================================================
% Top 10 rows of four rankings: long intervals (missed strokes) and short intervals
% (false peaks) for TPD and TPR.

tabelle = {};
titoli  = {};
for att = {'TPD', 'TPR'}
    act   = att{1};
    nomi  = fieldnames(filt_matrix.(act));

    T_max = table(nomi, peaksStruct.(act).rapportoMaxMediano', 'VariableNames', {'Name', 'MaxRatio'});
    T_min = table(nomi, peaksStruct.(act).rapportoMinMediano', 'VariableNames', {'Name', 'MinRatio'});

    tabelle(end+1:end+2) = {sortrows(T_max, 'MaxRatio', 'descend'), sortrows(T_min, 'MinRatio', 'ascend')};
    titoli(end+1:end+2)  = {[act ' - missed (max/median)'], [act ' - false (min/median)']};
end

for c = 1:numel(tabelle)
    T = tabelle{c};
    fprintf('\n=== %s ===\n', titoli{c});
    disp(T(1:min(10, height(T)), :))
end

%% ==========================================================================================
%  ============================  6 - FALSE PEAK REMOVAL  ====================================
%  ==========================================================================================
% Two peaks closer than 0.6 x median interval: one of them is false. The lower one is removed.
% Only the FIRST short interval is handled at each iteration, then the intervals are recomputed.
% The median is computed ONCE, before removing anything.
% Results are stored in locPulito / picchiPulito, without touching loc.

IntTolti = struct();
for k = 1:numel(activities)
    activityName = activities{k};
    nomiAcquisizioni = fieldnames(filt_matrix.(activityName));
    nReg = numel(nomiAcquisizioni);
    totTolti = 0;

    for i = 1:nReg
        nome_File = nomiAcquisizioni{i};
        loc = peaksStruct.(activityName).(nome_File).loc;
        pk  = peaksStruct.(activityName).(nome_File).picchi;
        nPrima = numel(loc);

        if numel(loc) >= 3
            intMedCampioni = median(diff(loc));
            while true
                intervalli = diff(loc);                            % recomputed at every iteration
                j = find(intervalli < 0.6*intMedCampioni, 1);      % only the FIRST short interval
                if isempty(j)                                      % none left -> done
                    break
                end
                if pk(j) < pk(j+1)
                    togli = j;
                else
                    togli = j + 1;
                end
                loc(togli) = [];
                pk(togli)  = [];
            end
        end

        ntolti = nPrima - numel(loc);
        if ntolti > 0
            fprintf('%-4s %-10s: removed %d peaks\n', activityName, nome_File, ntolti);
        end
        totTolti = totTolti + ntolti;

        peaksStruct.(activityName).(nome_File).locPulito    = loc;
        peaksStruct.(activityName).(nome_File).picchiPulito = pk;
    end

    IntTolti.(activityName) = totTolti;
    fprintf('%s: total peaks removed = %d\n\n', activityName, totTolti);
end

%% ==========================================================================================
%  ============================  7 - WINDOW EXTRACTION  =====================================
%  ==========================================================================================
% One 1 s window (50 samples) per stroke: 25 samples before the peak, the peak, 24 after.

finestreAcc   = {};
finestreGyro  = {};
Y             = {};
soggetto      = {};
registrazione = {};
posizione     = [];

durataFinestra = round(1.0 * fs);           % 50 samples at 50 Hz
n = 0;                                      % windows saved
scartate = 0;                               % peaks discarded at the edges
nPicchiTot = 0;                             % peaks after cleaning, all recordings

for j = 1:numel(activities)
    activityName = activities{j};
    nomiAcquisizioni = fieldnames(filt_matrix.(activityName));
    for k = 1:numel(nomiAcquisizioni)
        fileName    = nomiAcquisizioni{k};
        locPulito   = peaksStruct.(activityName).(fileName).locPulito;
        segnaleAcc  = filt_matrix.(activityName).(fileName).Acc;
        segnaleGyro = filt_matrix.(activityName).(fileName).Gyro;
        nPicchiTot  = nPicchiTot + numel(locPulito);

        for i = 1:numel(locPulito)
            peak_position = locPulito(i);
            indice_inizio = peak_position - durataFinestra/2;
            indice_fine   = peak_position + durataFinestra/2 - 1;

            if indice_inizio < inizio || indice_fine > size(segnaleAcc, 1)
                scartate = scartate + 1;
                continue
            end

            n = n + 1;                              % increases ONLY when a window is saved
            finestreAcc{n}   = segnaleAcc(indice_inizio:indice_fine, :);
            finestreGyro{n}  = segnaleGyro(indice_inizio:indice_fine, :);
            Y{n}             = activityName;
            parti            = strsplit(fileName, '_');
            soggetto{n}      = parti{1};
            registrazione{n} = fileName;
            posizione(n)     = peak_position;
        end
    end
end

% Checks
fprintf('Peaks: %d | windows saved: %d | discarded at the edges: %d\n', nPicchiTot, n, scartate);
disp(unique(cellfun(@(w) size(w, 1), finestreAcc)))      % must print only 50

% position of the magnitude maximum in every window: should be 26
% (a few exceptions come from the chained suppression of MinPeakDistance)
posMax = zeros(1, n);
for w = 1:n
    [~, posMax(w)] = max(sqrt(sum(finestreAcc{w}.^2, 2)));
end
fprintf('Windows with the peak at sample 26: %d of %d\n', sum(posMax == 26), n);

%% ==========================================================================================
%  ============================  8 - DATA MATRIX, LABELS, SAVE  =============================
%  ==========================================================================================

X = zeros(durataFinestra, 6, n, 'single');               % time x channels x windows
for i = 1:n
    X(:, :, i) = single([finestreAcc{i}, finestreGyro{i}]);
end

Y             = categorical(Y)';
soggetto      = categorical(soggetto');
registrazione = registrazione';
posizione     = posizione';
summary(Y)

save('windows.mat', 'X', 'Y', 'soggetto', 'registrazione', 'posizione', 'fs', 'durataFinestra');
save('preprocessing.mat', 'peaksStruct', 'filt_matrix', 'fs', 'inizio');

% check sizes and classes
size(Y), size(soggetto)
whos -file windows.mat

%% ==========================================================================================
%  ============================  9 - THRESHOLD STATISTICS FOR THE ONLINE DETECTOR  ==========
%  ==========================================================================================
% TRAIN subjects only. For each activity: the offline thresholds and the maximum magnitude
% in the 3-4 s segment (used as a rough "rest" level). Basis for the online minimum threshold (2).

soggetti_Tra = {'P01', 'P03', 'P05', 'P06', 'P08', 'P09', 'P11'};

statSoglieTrain = struct();

for k = 1:numel(activities)
    ActivityName = activities{k};
    nomiAcquisizioni = fieldnames(filt_matrix.(ActivityName));
    NomiTrain = nomiAcquisizioni(startsWith(nomiAcquisizioni, soggetti_Tra));
    Soglia   = zeros(numel(NomiTrain), 1);
    FermoMax = zeros(numel(NomiTrain), 1);

    for i = 1:numel(NomiTrain)
        nomeTrain   = NomiTrain{i};
        Soglia(i)   = peaksStruct.(ActivityName).(nomeTrain).soglia;
        FermoMax(i) = max(peaksStruct.(ActivityName).(nomeTrain).modulo(3*fs+1:4*fs));
        statSoglieTrain.(ActivityName).(nomeTrain).Soglia = Soglia(i);
    end

    statSoglieTrain.(ActivityName).SoglieTot         = Soglia;
    statSoglieTrain.(ActivityName).SogliaMedia       = mean(Soglia);
    statSoglieTrain.(ActivityName).SogliaMediana     = median(Soglia);
    statSoglieTrain.(ActivityName).SogliaMin         = min(Soglia);
    statSoglieTrain.(ActivityName).SogliaMax         = max(Soglia);
    statSoglieTrain.(ActivityName).Soglie5Percentile = prctile(Soglia, 5);
    statSoglieTrain.(ActivityName).FermoMaxTot       = FermoMax;          % one value per file
    statSoglieTrain.(ActivityName).FermoMax          = max(FermoMax);
    statSoglieTrain.(ActivityName).Fermo95Perc       = prctile(FermoMax, 95);
end

for k = 1:numel(activities)
    s = statSoglieTrain.(activities{k});
    fprintf('%-4s | min threshold %5.2f | 5th perc %5.2f | max at 3-4 s %5.2f | 95th perc at 3-4 s %5.2f\n', ...
        activities{k}, s.SogliaMin, s.Soglie5Percentile, s.FermoMax, s.Fermo95Perc);
end

save('threshold_stats_train.mat', 'statSoglieTrain')
